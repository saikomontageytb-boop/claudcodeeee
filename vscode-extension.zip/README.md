# Unlimited Claud Agent

Agent de code pour VS Code, connecté à ton compte Unlimited Claud. **Réservé aux membres Premium** : l'extension se débloque avec une clé premium active.

## Ce qu'il sait faire

- choisir le modèle (Claude, Gemini, Llama, Mistral…) directement dans le panneau ;
- lister des dossiers, lire des fichiers et chercher du texte dans le projet ouvert ;
- créer et modifier des fichiers (confirmation avec aperçu avant chaque écriture) ;
- lancer des commandes dans un terminal (confirmation avant chaque commande).

Les fichiers `.env`, les clés privées et le dossier `.git` ne sont jamais lus ni envoyés. Rien ne peut sortir du dossier ouvert.

## Utilisation

1. Clique sur l'icône Unlimited Claud dans la barre latérale.
2. Entre ta clé premium (`UC-…`, déjà activée sur le site) avec le bouton du panneau.
3. Connecte-toi avec ton compte du site au premier message.
4. Choisis le modèle dans le sélecteur, décris la tâche. Désactive « Agent » pour un simple chat.

Commandes (Ctrl+Maj+P) : « Unlimited Claud : Choisir le modèle », « Entrer une clé premium », « Se connecter », « Se déconnecter », « Nouveau chat ».

## Quota

Chaque étape de l'agent compte comme un message de ton quota quotidien premium.