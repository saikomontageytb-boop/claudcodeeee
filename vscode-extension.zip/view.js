'use strict';

const crypto = require('crypto');
const vscode = require('vscode');

const MAX_LOG = 500;
const MAX_INPUT = 20000;
const MAX_COPY = 200000;
const MODEL_ID = /^[\w.\-]{1,64}$/;

function render(webview, extensionUri) {
  const nonce = crypto.randomBytes(16).toString('hex');
  const media = (file) => webview.asWebviewUri(vscode.Uri.joinPath(extensionUri, 'media', file));
  const csp = webview.cspSource;
  return `<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src ${csp} data:; style-src ${csp}; script-src 'nonce-${nonce}';">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Unlimited Claud</title>
<link rel="stylesheet" href="${media('chat.css')}">
</head>
<body>
<header class="top">
  <div class="logo" aria-hidden="true"></div>
  <div class="brand"><b>Unlimited Claud</b><span id="usage">Agent de code</span></div>
  <span id="badge" class="pill premium" hidden>PREMIUM</span>
  <button id="h-new" class="icon-btn" type="button" title="Nouveau chat" aria-label="Nouveau chat">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
  </button>
  <button id="h-key" class="icon-btn" type="button" title="Clé premium" aria-label="Entrer une clé premium">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3M14 9l2 2"/></svg>
  </button>
  <button id="h-skills" class="icon-btn" type="button" title="Skills" aria-label="Gérer les skills">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13 2L4 14h7l-1 8 9-12h-7z"/></svg>
  </button>
  <button id="h-login" class="icon-btn" type="button" title="Connexion au compte" aria-label="Connexion au compte">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/></svg>
  </button>
</header>

<section id="lock" class="lock">
  <div class="hero-logo" aria-hidden="true"></div>
  <h1 id="lock-title">Vérification de ton accès…</h1>
  <p id="lock-text"></p>
  <ul id="perks" class="perks" hidden>
    <li>Tous les modèles : Claude, Gemini, Llama, Mistral…</li>
    <li>Mode agent : lit, modifie, lance des commandes</li>
    <li>Aperçu et confirmation avant chaque écriture</li>
  </ul>
  <div id="lock-actions" class="actions" hidden>
    <button id="btn-key" class="btn primary" type="button">Entrer ma clé premium</button>
    <button id="btn-site" class="btn" type="button">Obtenir une clé</button>
    <button id="btn-retry" class="btn primary" type="button" hidden>Réessayer</button>
  </div>
</section>

<div id="main" class="main" hidden>
  <div id="log" class="log" role="log" aria-live="polite" aria-label="Conversation" tabindex="0"></div>
  <div id="status" class="status" role="status" hidden><span class="pulse"></span><span id="status-text"></span></div>
  <footer class="composer">
    <div id="slash" class="slash" role="listbox" aria-label="Commandes" hidden></div>
    <div id="pop" class="pop" role="dialog" aria-label="Sélecteur" hidden></div>
    <div class="box">
      <div id="files" class="files" aria-label="Fichiers joints" hidden></div>
      <label for="input" class="sr">Message</label>
      <textarea id="input" rows="2" placeholder="Demande quelque chose à l'agent…"></textarea>
      <div class="tools">
        <button id="attach" class="chipbtn icon" type="button" title="Joindre des fichiers" aria-label="Joindre des fichiers">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
        </button>
        <label for="model" class="sr">Modèle</label>
        <select id="model" class="model" title="Choisir le modèle" hidden></select>
        <button id="model-btn" class="chipbtn" type="button" aria-haspopup="true" aria-expanded="false" title="Choisir le modèle">
          <span id="model-name">Modèle</span>
          <svg class="caret" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
        </button>
        <button id="effort-btn" class="chipbtn" type="button" aria-haspopup="true" aria-expanded="false" title="Niveau de raisonnement">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/></svg>
          <span id="effort-name">Moyen</span>
          <svg class="caret" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
        </button>
        <button id="perm-btn" class="chipbtn" type="button" aria-haspopup="true" aria-expanded="false" title="Permissions de modification des fichiers">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/></svg>
          <span id="perm-name">Demander avant</span>
          <svg class="caret" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
        </button>
        <label class="switch" title="Mode agent : lit les fichiers, les modifie et lance des commandes">
          <input type="checkbox" id="agent" checked>
          <span class="track"></span>
          <span class="sw-label">Agent</span>
        </label>
        <span class="grow"></span>
        <button id="stop" class="stop" type="button" title="Arrêter" aria-label="Arrêter" hidden>
          <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><rect x="6" y="6" width="12" height="12" rx="2"/></svg>
        </button>
        <button id="send" class="send" type="button" title="Envoyer" aria-label="Envoyer">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 19V5M5 12l7-7 7 7"/></svg>
        </button>
      </div>
    </div>
    <p class="hint">Entrée pour envoyer · Maj+Entrée pour une nouvelle ligne · / pour les commandes</p>
  </footer>
</div>
<script nonce="${nonce}" src="${media('chat.js')}"></script>
</body>
</html>`;
}

// Webview view shown in the activity bar. Keeps the state so it survives the view being re-created.
class ChatView {
  constructor(handlers, extensionUri) {
    this.h = handlers;
    this.extensionUri = extensionUri;
    this.view = null;
    this.log = [];
    this.busy = false;
    this.usage = '';
    this.access = { state: 'checking' };
    this.models = { models: [], selected: '' };
    this.skills = [];
    this.prefs = { effort: 'med', permissions: 'ask' };
    this.attached = [];
  }

  resolveWebviewView(webviewView) {
    this.view = webviewView;
    webviewView.webview.options = {
      enableScripts: true,
      localResourceRoots: [vscode.Uri.joinPath(this.extensionUri, 'media')]
    };
    webviewView.webview.html = render(webviewView.webview, this.extensionUri);
    webviewView.webview.onDidReceiveMessage((m) => this.onMessage(m));
    webviewView.onDidDispose(() => {
      this.view = null;
    });
  }

  onMessage(m) {
    if (!m || typeof m.type !== 'string') return;
    switch (m.type) {
      case 'ready':
        this.post(Object.assign({ type: 'access' }, this.access));
        this.post(Object.assign({ type: 'models' }, this.models));
        this.post({ type: 'skills', skills: this.skills });
        this.post(Object.assign({ type: 'prefs' }, this.prefs));
        this.post({ type: 'attachments', files: this.attached });
        this.post({ type: 'reset' });
        this.log.forEach((e) => this.post({ type: 'add', role: e.role, text: e.text }));
        this.post({ type: 'busy', value: this.busy });
        this.post({ type: 'usage', text: this.usage });
        this.h.onReady();
        break;
      case 'send':
        if (typeof m.text === 'string' && m.text.trim() && m.text.length <= MAX_INPUT) {
          this.h.onSend(m.text, m.agent !== false);
        }
        break;
      case 'model':
        if (typeof m.id === 'string' && MODEL_ID.test(m.id)) this.h.onModel(m.id);
        break;
      case 'copy':
        if (typeof m.text === 'string') void vscode.env.clipboard.writeText(m.text.slice(0, MAX_COPY));
        break;
      case 'stop':
        this.h.onStop();
        break;
      case 'clear':
        this.h.onClear();
        break;
      case 'login':
        this.h.onLogin();
        break;
      case 'setKey':
        this.h.onSetKey();
        break;
      case 'skills':
        this.h.onSkills();
        break;
      case 'logout':
        this.h.onLogout();
        break;
      case 'pickModel':
        this.h.onPickModel();
        break;
      case 'skillToggle':
        if (typeof m.id === 'string' && m.id.length <= 64) this.h.onSkillToggle(m.id);
        break;
      case 'effort':
        this.h.onEffort(String(m.value || ''));
        break;
      case 'permissions':
        this.h.onPermissions(String(m.value || ''));
        break;
      case 'attach':
        this.h.onAttach();
        break;
      case 'detach':
        this.h.onDetach(Number(m.index));
        break;
      case 'openSite':
        this.h.onOpenSite();
        break;
      case 'retry':
        this.h.onRetry();
        break;
      default:
        break;
    }
  }

  post(msg) {
    if (this.view) this.view.webview.postMessage(msg);
  }

  add(role, text) {
    this.log.push({ role, text });
    if (this.log.length > MAX_LOG) this.log.shift();
    this.post({ type: 'add', role, text });
  }

  reset() {
    this.log = [];
    this.post({ type: 'reset' });
  }

  setBusy(value) {
    this.busy = value;
    this.post({ type: 'busy', value });
  }

  setStatus(text) {
    this.post({ type: 'status', text });
  }

  setUsage(text) {
    this.usage = text;
    this.post({ type: 'usage', text });
  }

  setAccess(access) {
    this.access = access;
    this.post(Object.assign({ type: 'access' }, access));
  }

  setSkills(skills) {
    this.skills = skills;
    this.post({ type: 'skills', skills });
  }

  setPrefs(prefs) {
    this.prefs = prefs;
    this.post(Object.assign({ type: 'prefs' }, prefs));
  }

  setAttachments(files) {
    this.attached = files;
    this.post({ type: 'attachments', files });
  }

  setModels(models, selected) {
    this.models = { models, selected };
    this.post(Object.assign({ type: 'models' }, this.models));
  }
}

module.exports = { ChatView };