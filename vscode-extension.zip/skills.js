'use strict';

// Pure helpers (no VS Code API) so they can be unit-tested with `node --test`.
// A skill is a named, reusable block of instructions that can be switched on or off.

const MAX_SKILLS = 20;
const NAME_MAX = 40;
const TEXT_MAX = 1500;
const TOTAL_MAX = 4000;

function makeId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

// Returns a valid list: bad entries are dropped, fields are trimmed and capped.
function clean(list) {
  if (!Array.isArray(list)) return [];
  const out = [];
  for (const s of list) {
    if (!s || typeof s !== 'object') continue;
    const name = String(s.name || '').trim().slice(0, NAME_MAX);
    const text = String(s.text || '').trim().slice(0, TEXT_MAX);
    if (!name || !text) continue;
    out.push({ id: String(s.id || '') || makeId(), name, text, on: s.on !== false });
    if (out.length >= MAX_SKILLS) break;
  }
  return out;
}

// Text appended to the "instructions" field of /api/chat: only the enabled skills.
function compose(list) {
  return clean(list)
    .filter((s) => s.on)
    .map((s) => 'Skill "' + s.name + '":\n' + s.text)
    .join('\n\n')
    .slice(0, TOTAL_MAX);
}

// Preset skills offered in the library (name <= NAME_MAX, text <= TEXT_MAX).
const LIBRARY = [
  {
    name: 'Revue de code',
    desc: 'Relit le code comme un reviewer exigeant',
    text: "Quand je te montre du code, relis-le comme un reviewer senior. Classe les remarques par gravité (bloquant, important, détail). Cherche les bugs, les cas limites oubliés, les problèmes de lisibilité et de performance. Pour chaque remarque, explique le problème en une phrase et propose la correction."
  },
  {
    name: 'Tests d\'abord',
    desc: 'Ajoute des tests à chaque changement',
    text: "Quand je demande du code ou une correction, écris aussi les tests correspondants avec le framework déjà utilisé dans le projet. Couvre le cas nominal, les cas limites et les erreurs. Lance les tests quand c'est possible et corrige jusqu'à ce qu'ils passent."
  },
  {
    name: 'Chasseur de bugs',
    desc: 'Trouve la cause racine avant de corriger',
    text: "Face à un bug, ne devine pas. Reproduis-le, lis les logs et le code concerné, formule une hypothèse, vérifie-la, puis corrige la cause racine plutôt que le symptôme. Termine en expliquant brièvement la cause et comment éviter que ça revienne."
  },
  {
    name: 'Refactoring propre',
    desc: 'Simplifie sans changer le comportement',
    text: "Quand je demande de nettoyer du code, garde exactement le même comportement. Fais de petits changements : noms explicites, fonctions courtes, suppression du code mort et des duplications. Respecte le style et les conventions du projet. N'ajoute aucune fonctionnalité."
  },
  {
    name: 'Audit sécurité',
    desc: 'Repère les failles courantes',
    text: "Vérifie le code côté sécurité : injections (SQL, commande, XSS), authentification et autorisations, secrets en clair, validation des entrées, dépendances risquées. Indique pour chaque faille la gravité, comment l'exploiter en une phrase et le correctif concret."
  },
  {
    name: 'Réponses concises',
    desc: 'Va droit au but',
    text: "Réponds de façon courte et directe. Pas d'introduction ni de répétition de la question. Donne d'abord la réponse, puis seulement les détails utiles. Utilise des listes courtes quand il y a plusieurs points."
  },
  {
    name: 'Prof pédagogue',
    desc: 'Explique simplement, étape par étape',
    text: "Explique comme un bon professeur : commence par l'idée générale avec une analogie simple, puis détaille étape par étape avec un exemple concret. Évite le jargon ou définis-le. Termine par une petite question pour vérifier que c'est compris."
  },
  {
    name: 'Documentation',
    desc: 'Rédige README et commentaires utiles',
    text: "Quand je demande de la documentation, écris-la pour quelqu'un qui découvre le projet : à quoi ça sert, comment l'installer, un exemple d'utilisation minimal, puis la référence. Commente le pourquoi plutôt que le quoi. Reste exact : ne décris que ce qui existe vraiment."
  },
  {
    name: 'Commits et PR',
    desc: 'Messages de commit et descriptions de PR',
    text: "Pour un commit, écris un titre impératif de 70 caractères maximum, puis un court paragraphe expliquant le pourquoi. Pour une pull request, structure la description en : résumé, changements, tests effectués, points d'attention."
  },
  {
    name: 'Planificateur',
    desc: 'Découpe une tâche en étapes claires',
    text: "Avant de coder une tâche non triviale, propose un plan court en étapes numérotées avec les fichiers concernés et les risques. Puis exécute les étapes dans l'ordre en indiquant la progression. Signale tout écart par rapport au plan."
  },
  {
    name: 'Traducteur FR/EN',
    desc: 'Traduit en gardant le ton',
    text: "Quand je donne un texte, traduis-le entre français et anglais (dans l'autre langue que celle du texte). Garde le ton, le sens et la mise en forme. Ne traduis pas le code ni les noms propres. Donne uniquement la traduction, sauf si une nuance mérite une note."
  },
  {
    name: 'Relecture d\'écrit',
    desc: 'Corrige orthographe, style et clarté',
    text: "Quand je te donne un texte, corrige l'orthographe, la grammaire et la ponctuation, puis améliore la clarté sans changer mon sens ni ma voix. Renvoie le texte corrigé, puis une courte liste des changements importants."
  }
];

module.exports = { MAX_SKILLS, NAME_MAX, TEXT_MAX, TOTAL_MAX, LIBRARY, makeId, clean, compose };