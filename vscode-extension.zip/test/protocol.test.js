'use strict';

const test = require('node:test');
const assert = require('node:assert');
const {
  INSTRUCTIONS,
  parseToolCalls,
  stripToolCalls,
  hasUnclosedWrite,
  hasDone,
  unfence,
  parseEditPairs,
  applyEdits,
  headTail
} = require('../protocol');

test('instructions fit the 2000 characters the site keeps', () => {
  assert.ok(INSTRUCTIONS.length <= 2000, 'length is ' + INSTRUCTIONS.length);
});

test('parses a self-closing read_file with attributes', () => {
  const calls = parseToolCalls('Je lis.\n<read_file path="src/a.js" start="1" end="20"/>');
  assert.strictEqual(calls.length, 1);
  assert.strictEqual(calls[0].name, 'read_file');
  assert.deepStrictEqual(calls[0].attrs, { path: 'src/a.js', start: '1', end: '20' });
});

test('parses several tags in order, including a pattern containing ">"', () => {
  const calls = parseToolCalls('<list_dir path="."/>\n<search pattern="=>" glob="**/*.js"/>');
  assert.deepStrictEqual(calls.map((c) => c.name), ['list_dir', 'search']);
  assert.strictEqual(calls[1].attrs.pattern, '=>');
});

test('write_file body may contain html and keeps its content', () => {
  const calls = parseToolCalls('<write_file path="a.html">\n<div>hi</div>\n</write_file>');
  assert.strictEqual(calls.length, 1);
  assert.strictEqual(unfence(calls[0].body), '<div>hi</div>');
});

test('edit_file inner search/replace is not mistaken for a search tool', () => {
  const calls = parseToolCalls('<edit_file path="a.js"><search>x</search><replace>y</replace></edit_file>');
  assert.strictEqual(calls.length, 1);
  assert.strictEqual(calls[0].name, 'edit_file');
  assert.deepStrictEqual(parseEditPairs(calls[0].body), [{ search: 'x', replace: 'y' }]);
});

test('unfence removes a markdown fence around the content', () => {
  assert.strictEqual(unfence('\n\x60\x60\x60js\nconst a = 1;\n\x60\x60\x60\n'), 'const a = 1;');
  assert.strictEqual(unfence('\n\x60\x60\x60\nline 1\nline 2\n\x60\x60\x60'), 'line 1\nline 2');
  assert.strictEqual(unfence('\nplain\n'), 'plain');
});

test('stripToolCalls keeps only the prose', () => {
  const out = stripToolCalls('Hello <read_file path="a"/> bye');
  assert.ok(!out.includes('<read_file'));
  assert.ok(out.startsWith('Hello'));
  assert.strictEqual(stripToolCalls('Done.\n<write_file path="a">abc'), 'Done.');
  assert.strictEqual(stripToolCalls('Voici le résultat.\n\x60\x60\x60xml\n<list_dir path="."/>\n\x60\x60\x60'), 'Voici le résultat.');
});

test('hasUnclosedWrite detects a reply cut inside a tag', () => {
  assert.strictEqual(hasUnclosedWrite('<write_file path="a">abc'), true);
  assert.strictEqual(hasUnclosedWrite('<write_file path="a">abc</write_file>'), false);
  assert.strictEqual(hasUnclosedWrite('no tag here'), false);
});

test('applyEdits keeps CRLF line endings', () => {
  const out = applyEdits('a\r\nb\r\nc\r\n', [{ search: '\nb\n', replace: '\nB\n' }]);
  assert.strictEqual(out, 'a\r\nB\r\nc\r\n');
});

test('applyEdits does not interpret $ patterns in the replacement', () => {
  assert.strictEqual(applyEdits('x = 1', [{ search: 'x = 1', replace: "x = '$&'" }]), "x = '$&'");
});

test('applyEdits rejects missing and ambiguous matches', () => {
  assert.throws(() => applyEdits('abc', [{ search: 'zzz', replace: 'y' }]), /not found/);
  assert.throws(() => applyEdits('aa', [{ search: 'a', replace: 'b' }]), /matches 2 places/);
  assert.throws(() => applyEdits('abc', []), /no <search>/);
});

test('headTail keeps both ends of a long text', () => {
  const out = headTail('A'.repeat(500) + 'B'.repeat(500), 100);
  assert.ok(out.startsWith('A'));
  assert.ok(out.endsWith('B'));
  assert.ok(out.includes('characters cut'));
});

test('hasDone sees the tag only outside write/edit/run bodies', () => {
  assert.strictEqual(hasDone('Fait.\n<run_command>mkdir port</run_command>\n<done/>'), true);
  assert.strictEqual(hasDone('<write_file path="a.md">fin <done/></write_file>'), false);
  assert.strictEqual(hasDone('<read_file path="a"/>'), false);
});

test('stripToolCalls removes the done tag', () => {
  assert.strictEqual(stripToolCalls('Dossier créé.\n<run_command>x</run_command>\n<done/>'), 'Dossier créé.');
});