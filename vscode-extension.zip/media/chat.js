(function () {
  'use strict';

  var vscode = acquireVsCodeApi();
  var $ = function (id) { return document.getElementById(id); };

  var log = $('log');
  var input = $('input');
  var sendBtn = $('send');
  var stopBtn = $('stop');
  var agentBox = $('agent');
  var statusEl = $('status');
  var statusText = $('status-text');
  var usageEl = $('usage');
  var badge = $('badge');
  var modelSel = $('model');
  var lockEl = $('lock');
  var mainEl = $('main');

  var FENCE = String.fromCharCode(96, 96, 96);
  var TICK = String.fromCharCode(96);
  var NL = String.fromCharCode(10);
  var SUGGESTIONS = [
    'Explique la structure de ce projet',
    'Trouve les bugs probables dans ce code',
    'Écris des tests pour le fichier ouvert'
  ];
  var GROUPS = ['Claude', 'GPT', 'Gemini', 'Open source'];

  var busy = false;
  var emptyEl = null;

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) { n.className = cls; }
    if (text !== undefined && text !== null) { n.textContent = text; }
    return n;
  }

  /* ---------- Light markdown (code fences, `code`, **bold**), built with DOM nodes only ---------- */
  function inline(parent, text) {
    var span = el('span', 'txt');
    var chunks = text.split(TICK);
    for (var i = 0; i < chunks.length; i++) {
      var chunk = chunks[i];
      if (!chunk) { continue; }
      if (i % 2 === 1) {
        if (i < chunks.length - 1) { span.appendChild(el('code', 'ic', chunk)); }
        else { span.appendChild(document.createTextNode(TICK + chunk)); }
        continue;
      }
      var bits = chunk.split('**');
      for (var j = 0; j < bits.length; j++) {
        if (!bits[j]) { continue; }
        if (j % 2 === 1) {
          if (j < bits.length - 1) { span.appendChild(el('strong', null, bits[j])); }
          else { span.appendChild(document.createTextNode('**' + bits[j])); }
        } else {
          span.appendChild(document.createTextNode(bits[j]));
        }
      }
    }
    parent.appendChild(span);
  }

  function codeBlock(parent, raw) {
    var lang = '';
    var body = raw;
    var nl = raw.indexOf(NL);
    if (nl !== -1) {
      var first = raw.slice(0, nl).trim();
      if (first.length <= 20 && first.indexOf(' ') === -1) {
        lang = first;
        body = raw.slice(nl + 1);
      }
    }
    body = body.replace(/\s+$/, '');

    var box = el('div', 'code');
    var head = el('div', 'code-head');
    head.appendChild(el('span', 'code-lang', lang || 'code'));
    var copy = el('button', 'copy', 'Copier');
    copy.type = 'button';
    copy.addEventListener('click', function () {
      vscode.postMessage({ type: 'copy', text: body });
      copy.textContent = 'Copié';
      setTimeout(function () { copy.textContent = 'Copier'; }, 1400);
    });
    head.appendChild(copy);
    var pre = el('pre');
    pre.appendChild(el('code', null, body));
    box.appendChild(head);
    box.appendChild(pre);
    parent.appendChild(box);
  }

  function renderRich(parent, text) {
    var parts = text.split(FENCE);
    for (var i = 0; i < parts.length; i++) {
      if (i % 2 === 0) {
        if (parts[i].trim()) { inline(parent, parts[i].replace(/^\n+|\n+$/g, '')); }
      } else {
        codeBlock(parent, parts[i]);
      }
    }
  }

  /* ---------- Conversation ---------- */
  function clearEmpty() {
    if (emptyEl && emptyEl.parentNode) { emptyEl.parentNode.removeChild(emptyEl); }
    emptyEl = null;
  }

  function showEmpty() {
    if (log.children.length) { return; }
    emptyEl = el('div', 'empty');
    emptyEl.appendChild(el('div', 'hero-logo'));
    emptyEl.appendChild(el('h2', null, 'Que veux-tu construire ?'));
    emptyEl.appendChild(el('p', null, 'Décris une tâche : l’agent lit ton projet, modifie les fichiers et lance des commandes, avec ton accord.'));
    var chips = el('div', 'chips');
    SUGGESTIONS.forEach(function (s) {
      var b = el('button', 'chip', s);
      b.type = 'button';
      b.addEventListener('click', function () {
        input.value = s;
        resizeInput();
        input.focus();
      });
      chips.appendChild(b);
    });
    emptyEl.appendChild(chips);
    log.appendChild(emptyEl);
  }

  function add(role, text) {
    clearEmpty();
    var node;
    if (role === 'user' || role === 'assistant') {
      node = el('div', 'msg ' + role);
      if (role === 'assistant') { node.appendChild(el('div', 'avatar')); }
      var bubble = el('div', 'bubble');
      if (role === 'assistant') { renderRich(bubble, text); } else { bubble.textContent = text; }
      node.appendChild(bubble);
    } else if (role === 'tool') {
      node = el('div', 'tool');
      node.appendChild(el('span', null, text));
      node.title = text;
    } else if (role === 'error') {
      node = el('div', 'err', text);
      node.setAttribute('role', 'alert');
    } else {
      node = el('div', 'note', text);
    }
    log.appendChild(node);
    log.scrollTop = log.scrollHeight;
  }

  function reset() {
    log.textContent = '';
    emptyEl = null;
    showEmpty();
  }

  /* ---------- State from the extension ---------- */
  function setBusy(value) {
    busy = Boolean(value);
    sendBtn.hidden = busy;
    stopBtn.hidden = !busy;
  }

  function setStatus(text) {
    var t = String(text || '');
    statusText.textContent = t;
    statusEl.hidden = !t;
  }

  function setAccess(m) {
    var state = m.state;
    var premium = state === 'premium';
    mainEl.hidden = !premium;
    lockEl.hidden = premium;
    badge.hidden = !premium;
    $('h-key').hidden = state === 'checking';

    if (premium) {
      badge.textContent = m.plan ? 'PREMIUM · ' + String(m.plan).toUpperCase() : 'PREMIUM';
      badge.title = m.expires ? String(m.expires) : 'Clé premium active';
      showEmpty();
      return;
    }

    var titles = {
      checking: 'Vérification de ton accès…',
      locked: 'Réservé aux membres Premium',
      error: 'Accès impossible à vérifier'
    };
    $('lock-title').textContent = titles[state] || titles.locked;
    $('lock-text').textContent = m.text || '';
    $('perks').hidden = state !== 'locked';
    $('lock-actions').hidden = state === 'checking';
    $('btn-retry').hidden = state !== 'error';
    $('btn-key').hidden = state === 'error';
    $('btn-site').hidden = state === 'error';
  }

  function groupOf(id) {
    if (id.indexOf('claude') === 0) { return 'Claude'; }
    if (id.indexOf('gpt') === 0) { return 'GPT'; }
    if (id.indexOf('gemini') === 0) { return 'Gemini'; }
    return 'Open source';
  }

  function fillModelSelect(m) {
    var list = Array.isArray(m.models) ? m.models : [];
    modelSel.textContent = '';
    if (!list.length) {
      modelSel.appendChild(el('option', null, 'Modèles indisponibles'));
      modelSel.disabled = true;
      return;
    }
    modelSel.disabled = false;
    GROUPS.forEach(function (g) {
      var items = list.filter(function (x) { return groupOf(x.id) === g; });
      if (!items.length) { return; }
      var group = document.createElement('optgroup');
      group.label = g;
      items.forEach(function (x) {
        var o = el('option', null, x.label + (x.reasoning ? ' (raisonnement)' : ''));
        o.value = x.id;
        if (x.id === m.selected) { o.selected = true; }
        group.appendChild(o);
      });
      modelSel.appendChild(group);
    });
    modelSel.title = 'Modèle : ' + (modelSel.options[modelSel.selectedIndex] ? modelSel.options[modelSel.selectedIndex].text : '');
  }

  /* ---------- Model / reasoning / permissions pickers + attachments ---------- */
  var popEl = $('pop');
  var filesEl = $('files');
  var barBtns = { model: $('model-btn'), effort: $('effort-btn'), perm: $('perm-btn') };
  var EFFORT_INFO = {
    none: ['Aucun', 'Pas de raisonnement, réponse la plus rapide'],
    minimal: ['Minimal', 'Très peu de raisonnement'],
    low: ['Faible', 'Raisonnement léger, rapide'],
    med: ['Moyen', 'Bon équilibre vitesse / qualité'],
    high: ['Élevé', 'Raisonnement approfondi'],
    xhigh: ['Très élevé', 'Raisonnement très poussé'],
    max: ['Maximum', 'Raisonnement maximal, le plus lent']
  };
  var PERMS = [
    { id: 'readOnly', name: 'Lecture seule', desc: 'Lit le projet, ne modifie rien et ne lance aucune commande' },
    { id: 'ask', name: 'Demander avant', desc: 'Demande ton accord avant chaque modification ou commande' },
    { id: 'all', name: 'Tout autoriser', desc: 'Modifie les fichiers et lance les commandes sans demander' }
  ];
  var groupOpen = {};
  var modelList = [];
  var modelId = '';
  var prefs = { effort: 'med', permissions: 'ask' };
  var openPop = '';

  function currentModel() {
    return modelList.filter(function (x) { return x.id === modelId; })[0] || null;
  }

  function effortList() {
    var cur = currentModel();
    return cur && Array.isArray(cur.efforts) && cur.efforts.length ? cur.efforts : ['low', 'med', 'high'];
  }

  function effortInfo(k) { return EFFORT_INFO[k] || [k, '']; }

  function permInfo(id) {
    return PERMS.filter(function (p) { return p.id === id; })[0] || PERMS[1];
  }

  function paintBar() {
    var cur = currentModel();
    $('model-name').textContent = cur ? cur.label : 'Modèle';
    $('effort-name').textContent = effortInfo(prefs.effort)[0];
    $('perm-name').textContent = permInfo(prefs.permissions).name;
    barBtns.model.disabled = !modelList.length;
    barBtns.effort.disabled = !modelList.length;
    if (openPop) { renderPop(); }
  }

  function closePop() {
    openPop = '';
    popEl.hidden = true;
    Object.keys(barBtns).forEach(function (k) { barBtns[k].setAttribute('aria-expanded', 'false'); });
  }

  function togglePop(kind) {
    if (openPop === kind) { closePop(); return; }
    closePop();
    openPop = kind;
    barBtns[kind].setAttribute('aria-expanded', 'true');
    renderPop();
    popEl.hidden = false;
    var on = popEl.querySelector('.opt.on');
    if (on && on.scrollIntoView) { on.scrollIntoView({ block: 'nearest' }); }
  }

  function optionBtn(name, desc, on, onClick) {
    var b = el('button', 'opt' + (on ? ' on' : ''));
    b.type = 'button';
    b.setAttribute('role', 'menuitemradio');
    b.setAttribute('aria-checked', on ? 'true' : 'false');
    var t = el('span', 'opt-t');
    t.appendChild(el('b', null, name));
    if (desc) { t.appendChild(el('span', null, desc)); }
    b.appendChild(t);
    if (on) { b.appendChild(el('span', 'tick', '✓')); }
    b.addEventListener('click', onClick);
    return b;
  }

  function renderModelGroups() {
    GROUPS.forEach(function (g) {
      var items = modelList.filter(function (x) { return groupOf(x.id) === g; });
      if (!items.length) { return; }
      var hasCur = items.some(function (x) { return x.id === modelId; });
      var open = groupOpen[g] === undefined ? hasCur : groupOpen[g];
      var sec = el('section', 'grp' + (open ? ' open' : ''));
      var head = el('button', 'grp-h');
      head.type = 'button';
      head.setAttribute('aria-expanded', open ? 'true' : 'false');
      head.appendChild(el('span', 'chev'));
      head.appendChild(el('b', null, g));
      head.appendChild(el('span', 'count', String(items.length)));
      head.addEventListener('click', function () { groupOpen[g] = !open; renderPop(); });
      sec.appendChild(head);
      if (open) {
        var body = el('div', 'grp-b');
        items.forEach(function (x) {
          body.appendChild(optionBtn(x.label, x.reasoning ? 'Raisonnement' : '', x.id === modelId, function () {
            closePop();
            vscode.postMessage({ type: 'model', id: x.id });
          }));
        });
        sec.appendChild(body);
      }
      popEl.appendChild(sec);
    });
  }

  function renderPop() {
    popEl.textContent = '';
    if (openPop === 'model') {
      popEl.appendChild(el('div', 'pop-t', 'Modèle'));
      renderModelGroups();
    } else if (openPop === 'effort') {
      popEl.appendChild(el('div', 'pop-t', 'Niveau de raisonnement'));
      effortList().forEach(function (k) {
        var info = effortInfo(k);
        popEl.appendChild(optionBtn(info[0], info[1], k === prefs.effort, function () {
          closePop();
          vscode.postMessage({ type: 'effort', value: k });
        }));
      });
    } else if (openPop === 'perm') {
      popEl.appendChild(el('div', 'pop-t', 'Modification des fichiers'));
      PERMS.forEach(function (p) {
        popEl.appendChild(optionBtn(p.name, p.desc, p.id === prefs.permissions, function () {
          closePop();
          vscode.postMessage({ type: 'permissions', value: p.id });
        }));
      });
    }
  }

  function setModels(m) {
    fillModelSelect(m);
    modelList = (Array.isArray(m.models) ? m.models : []).filter(function (x) {
      return x && typeof x.id === 'string' && typeof x.label === 'string';
    });
    modelId = String(m.selected || '');
    paintBar();
  }

  function setPrefs(m) {
    prefs = { effort: String(m.effort || 'med'), permissions: String(m.permissions || 'ask') };
    paintBar();
  }

  function fmtSize(n) {
    return n >= 1000 ? (n / 1000).toFixed(1) + ' ko' : n + ' o';
  }

  function renderFiles(list) {
    filesEl.textContent = '';
    filesEl.hidden = !list.length;
    list.forEach(function (f, i) {
      var chip = el('span', 'file');
      chip.appendChild(el('span', 'file-n', f.name));
      chip.appendChild(el('span', 'file-s', fmtSize(f.size)));
      var x = el('button', 'file-x', '×');
      x.type = 'button';
      x.title = 'Retirer';
      x.setAttribute('aria-label', 'Retirer ' + f.name);
      x.addEventListener('click', function () { vscode.postMessage({ type: 'detach', index: i }); });
      chip.appendChild(x);
      filesEl.appendChild(chip);
    });
  }

  Object.keys(barBtns).forEach(function (k) {
    barBtns[k].addEventListener('click', function (e) { e.stopPropagation(); togglePop(k); });
  });
  popEl.addEventListener('click', function (e) { e.stopPropagation(); });
  document.addEventListener('click', function () { if (openPop) { closePop(); } });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && openPop) {
      var btn = barBtns[openPop];
      closePop();
      if (btn) { btn.focus(); }
    }
  });
  $('attach').addEventListener('click', function () { vscode.postMessage({ type: 'attach' }); });

  /* ---------- Input ---------- */
  function resizeInput() {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 200) + 'px';
  }

  /* ---------- Slash commands (/model, /skills, ...) ---------- */
  var slashEl = $('slash');
  var skillsList = [];
  var slashItems = [];
  var slashIdx = 0;

  function norm(s) { return String(s).toLowerCase().replace(/[\s_-]+/g, ' ').trim(); }

  function modelMatches(q) {
    if (modelSel.disabled) { return []; }
    var n = norm(q);
    var all = Array.prototype.slice.call(modelSel.options).filter(function (o) {
      return !n || norm(o.value).indexOf(n) > -1 || norm(o.text).indexOf(n) > -1;
    });
    var exact = all.filter(function (o) { return norm(o.value) === n || norm(o.text) === n; });
    return exact.length ? exact : all;
  }

  function useModel(o) {
    modelSel.value = o.value;
    modelSel.title = 'Modèle : ' + o.text;
    vscode.postMessage({ type: 'model', id: o.value });
    add('info', 'Modèle : ' + o.text);
  }

  function skillMatches(q) {
    var n = norm(q);
    var all = skillsList.filter(function (k) { return !n || norm(k.name).indexOf(n) > -1; });
    var exact = all.filter(function (k) { return norm(k.name) === n; });
    return exact.length ? exact : all;
  }

  function useSkill(k) {
    vscode.postMessage({ type: 'skillToggle', id: k.id });
    add('info', 'Skill « ' + k.name + ' » ' + (k.on ? 'désactivé' : 'activé') + '.');
  }

  function cmdModel(arg) {
    if (!arg) { vscode.postMessage({ type: 'pickModel' }); return; }
    var found = modelMatches(arg);
    if (!found.length) { add('error', 'Aucun modèle ne correspond à « ' + arg + ' ».'); return; }
    useModel(found[0]);
  }

  function cmdSkills(arg) {
    if (!arg) { vscode.postMessage({ type: 'skills' }); return; }
    var found = skillMatches(arg);
    if (!found.length) { add('error', 'Aucun skill ne correspond à « ' + arg + ' ».'); return; }
    useSkill(found[0]);
  }

  function cmdAgent() {
    agentBox.checked = !agentBox.checked;
    add('info', 'Mode agent ' + (agentBox.checked ? 'activé' : 'désactivé') + '.');
  }

  function cmdHelp() {
    input.value = '/';
    resizeInput();
    input.focus();
    slashIdx = 0;
    renderSlash();
  }

  var CMDS = [
    { n: 'new', al: ['nouveau', 'clear'], d: 'Nouvelle conversation',
      run: function () { vscode.postMessage({ type: 'clear' }); } },
    { n: 'model', al: ['modele', 'modèle', 'models'], d: 'Choisir le modèle (/model nom)', run: cmdModel,
      sub: function (arg) {
        return modelMatches(arg).slice(0, 8).map(function (o) {
          return { name: o.text, desc: o.value === modelSel.value ? '✓' : '', run: function () { useModel(o); } };
        });
      } },
    { n: 'skills', al: ['skill'], d: 'Gérer les skills (/skills nom en active ou désactive un)', run: cmdSkills,
      sub: function (arg) {
        return skillMatches(arg).slice(0, 8).map(function (k) {
          return { name: k.name, desc: k.on ? 'activé' : 'désactivé', run: function () { useSkill(k); } };
        });
      } },
    { n: 'agent', al: [], d: 'Activer ou désactiver le mode agent', run: cmdAgent },
    { n: 'login', al: ['connexion'], d: 'Se connecter au compte',
      run: function () { vscode.postMessage({ type: 'login' }); } },
    { n: 'logout', al: ['deconnexion', 'déconnexion'], d: 'Se déconnecter',
      run: function () { vscode.postMessage({ type: 'logout' }); } },
    { n: 'key', al: ['cle', 'clé'], d: 'Entrer ou retirer la clé premium',
      run: function () { vscode.postMessage({ type: 'setKey' }); } },
    { n: 'site', al: [], d: 'Ouvrir le site',
      run: function () { vscode.postMessage({ type: 'openSite' }); } },
    { n: 'help', al: ['aide', 'commands', 'commandes'], d: 'Lister toutes les commandes', run: cmdHelp }
  ];

  function findCmd(name) {
    return CMDS.filter(function (c) { return c.n === name || c.al.indexOf(name) > -1; })[0] || null;
  }

  function slashParse() {
    var v = input.value;
    if (v.charAt(0) !== '/' || v.indexOf(NL) > -1) { return null; }
    var m = /^\/(\S*)(?:\s+([\s\S]*))?$/.exec(v);
    if (!m) { return null; }
    return { name: m[1].toLowerCase(), arg: (m[2] || '').trim(), space: /^\/\S*\s/.test(v) };
  }

  function renderSlash() {
    var p = slashParse();
    var list = [];
    if (p && !p.space) {
      list = CMDS.filter(function (c) {
        return c.n.indexOf(p.name) === 0 || c.al.some(function (a) { return a.indexOf(p.name) === 0; });
      }).map(function (c) {
        return { name: '/' + c.n, desc: c.d, complete: '/' + c.n + (c.sub ? ' ' : ''), run: function () { c.run(''); } };
      });
    } else if (p) {
      var found = findCmd(p.name);
      if (found && found.sub) { list = found.sub(p.arg); }
    }
    slashItems = list;
    slashEl.textContent = '';
    if (!list.length) { slashEl.hidden = true; return; }
    if (slashIdx >= list.length || slashIdx < 0) { slashIdx = 0; }
    list.forEach(function (it, i) {
      var b = el('button', 'sli' + (i === slashIdx ? ' on' : ''));
      b.type = 'button';
      b.tabIndex = -1;
      b.setAttribute('role', 'option');
      b.setAttribute('aria-selected', i === slashIdx ? 'true' : 'false');
      b.appendChild(el('b', null, it.name));
      b.appendChild(el('span', null, it.desc || ''));
      b.addEventListener('mousedown', function (e) { e.preventDefault(); });
      b.addEventListener('click', function () { runSlashItem(it); });
      slashEl.appendChild(b);
    });
    slashEl.hidden = false;
    var on = slashEl.querySelector('.sli.on');
    if (on && on.scrollIntoView) { on.scrollIntoView({ block: 'nearest' }); }
  }

  function runSlashItem(it) {
    if (!it) { return; }
    input.value = '';
    resizeInput();
    slashIdx = 0;
    renderSlash();
    it.run();
  }

  // Runs "/name args" typed in full. Returns false if it is not a known command (it is then sent as a message).
  function runTyped() {
    var p = slashParse();
    if (!p) { return false; }
    var cmd = findCmd(p.name);
    if (!cmd) { return false; }
    input.value = '';
    resizeInput();
    renderSlash();
    cmd.run(p.arg);
    return true;
  }

  function slashKey(e) {
    var n = slashItems.length;
    if (!n) { return false; }
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      slashIdx = (slashIdx + (e.key === 'ArrowDown' ? 1 : -1) + n) % n;
      renderSlash();
      e.preventDefault();
      return true;
    }
    if (e.key === 'Tab' && !e.shiftKey) {
      var it = slashItems[slashIdx];
      if (!it || !it.complete) { return false; }
      input.value = it.complete;
      resizeInput();
      slashIdx = 0;
      renderSlash();
      e.preventDefault();
      return true;
    }
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      runSlashItem(slashItems[slashIdx]);
      return true;
    }
    if (e.key === 'Escape') { slashEl.hidden = true; return true; }
    return false;
  }

  function send() {
    if (runTyped()) { return; }
    var text = input.value.trim();
    if (!text || busy) { return; }
    vscode.postMessage({ type: 'send', text: text, agent: agentBox.checked });
    input.value = '';
    resizeInput();
    renderSlash();
  }

  sendBtn.addEventListener('click', send);
  stopBtn.addEventListener('click', function () { vscode.postMessage({ type: 'stop' }); });
  input.addEventListener('input', function () { resizeInput(); slashIdx = 0; renderSlash(); });
  input.addEventListener('focus', renderSlash);
  input.addEventListener('blur', function () { slashEl.hidden = true; });
  input.addEventListener('keydown', function (e) {
    if (!slashEl.hidden && !e.isComposing && slashKey(e)) { return; }
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
      e.preventDefault();
      send();
    }
  });
  modelSel.addEventListener('change', function () {
    vscode.postMessage({ type: 'model', id: modelSel.value });
  });

  $('h-new').addEventListener('click', function () { vscode.postMessage({ type: 'clear' }); });
  $('h-key').addEventListener('click', function () { vscode.postMessage({ type: 'setKey' }); });
  $('h-login').addEventListener('click', function () { vscode.postMessage({ type: 'login' }); });
  $('h-skills').addEventListener('click', function () { vscode.postMessage({ type: 'skills' }); });
  $('btn-key').addEventListener('click', function () { vscode.postMessage({ type: 'setKey' }); });
  $('btn-site').addEventListener('click', function () { vscode.postMessage({ type: 'openSite' }); });
  $('btn-retry').addEventListener('click', function () { vscode.postMessage({ type: 'retry' }); });

  window.addEventListener('message', function (event) {
    var m = event.data || {};
    switch (m.type) {
      case 'add': add(String(m.role), String(m.text)); break;
      case 'reset': reset(); break;
      case 'busy': setBusy(m.value); break;
      case 'status': setStatus(m.text); break;
      case 'usage': usageEl.textContent = String(m.text || 'Agent de code'); break;
      case 'access': setAccess(m); break;
      case 'models': setModels(m); break;
      case 'prefs': setPrefs(m); break;
      case 'attachments':
        renderFiles((Array.isArray(m.files) ? m.files : []).filter(function (f) {
          return f && typeof f.name === 'string' && typeof f.size === 'number';
        }));
        break;
      case 'skills':
        skillsList = (Array.isArray(m.skills) ? m.skills : []).filter(function (k) {
          return k && typeof k.id === 'string' && typeof k.name === 'string';
        });
        renderSlash();
        break;
      default: break;
    }
  });

  setBusy(false);
  vscode.postMessage({ type: 'ready' });
})();