'use strict';

const vscode = require('vscode');
const fs = require('fs/promises');
const path = require('path');
const { exec } = require('child_process');
const { unfence, parseEditPairs, applyEdits, headTail } = require('./protocol');

const RESULT_CAP = 6500; // the site keeps 8000 characters per message
const MAX_FILE_BYTES = 1024 * 1024;
const MAX_WRITE_CHARS = 100000;
const SKIP_DIRS = new Set(['node_modules', '.git']);

// Everything the agent reads goes to a remote service, so secrets are never readable or writable.
const SENSITIVE = /(^|[\\/])(\.env(\..*)?|\.npmrc|id_(rsa|dsa|ecdsa|ed25519)[^\\/]*|[^\\/]*\.(pem|key|pfx|p12|keystore|jks)|credentials[^\\/]*\.json)$/i;
const GIT_DIR = /(^|[\\/])\.git([\\/]|$)/;

function isOutside(rel) {
  return rel === '..' || rel.startsWith('..' + path.sep) || path.isAbsolute(rel);
}

function escapeRegExp(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function byDirThenName(a, b) {
  return (b.isDirectory() - a.isDirectory()) || a.name.localeCompare(b.name);
}

function preview(text, lines) {
  const all = text.split(/\r?\n/);
  const shown = all.slice(0, lines).map((l) => (l.length > 120 ? l.slice(0, 120) + '…' : l));
  return shown.join('\n') + (all.length > lines ? '\n… (' + (all.length - lines) + ' lignes de plus)' : '');
}

class Tools {
  // getMode returns 'readOnly' | 'ask' | 'all' (read at every action, so a change applies immediately).
  constructor(getMode) {
    this.getMode = typeof getMode === 'function' ? getMode : () => 'ask';
    this.allowWrites = false; // "always allow" for this chat session
  }

  reset() {
    this.allowWrites = false;
  }

  root() {
    const folders = vscode.workspace.workspaceFolders;
    if (!folders || !folders.length) throw new Error('No folder is open in VS Code.');
    return folders[0].uri.fsPath;
  }

  // Resolves a workspace-relative path and refuses anything outside the workspace (symlinks included)
  // or sensitive.
  async resolve(rel) {
    if (typeof rel !== 'string' || !rel.trim()) throw new Error('missing path attribute');
    const root = this.root();
    const abs = path.resolve(root, rel.trim());
    const relative = path.relative(root, abs);
    if (isOutside(relative)) throw new Error('path is outside the workspace: ' + rel.trim());
    if (SENSITIVE.test(relative) || GIT_DIR.test(relative)) {
      throw new Error('access blocked (secrets or git internals): ' + relative);
    }

    const realRoot = await fs.realpath(root);
    let probe = abs;
    for (;;) {
      try {
        const real = await fs.realpath(probe);
        if (isOutside(path.relative(realRoot, real))) throw new Error('path resolves outside the workspace: ' + rel.trim());
        break;
      } catch (e) {
        if (e && e.code === 'ENOENT') {
          const parent = path.dirname(probe);
          if (parent === probe) break;
          probe = parent;
          continue;
        }
        throw e;
      }
    }
    return { abs, relative: relative || '.' };
  }

  async confirm(kind, title, detail) {
    const mode = this.getMode();
    if (mode === 'readOnly') {
      throw new Error('read-only mode: writing files and running commands are disabled. Ask the user to switch the permission mode.');
    }
    if (mode === 'all') return true;
    if (kind === 'write' && this.allowWrites) return true;
    const allow = 'Autoriser';
    const always = 'Toujours (cette session)';
    const buttons = kind === 'write' ? [allow, always] : [allow];
    const pick = await vscode.window.showWarningMessage(title, { modal: true, detail }, ...buttons);
    if (pick === always) {
      this.allowWrites = true;
      return true;
    }
    return pick === allow;
  }

  async brief() {
    const folders = vscode.workspace.workspaceFolders;
    if (!folders || !folders.length) return 'No folder is open.';
    const root = folders[0].uri.fsPath;
    let names = [];
    try {
      const entries = await fs.readdir(root, { withFileTypes: true });
      names = entries
        .filter((e) => !SKIP_DIRS.has(e.name) && !SENSITIVE.test(e.name))
        .sort(byDirThenName)
        .slice(0, 60)
        .map((e) => e.name + (e.isDirectory() ? '/' : ''));
    } catch (e) {
      names = [];
    }
    return 'Folder: ' + path.basename(root) + '\nOS: ' + process.platform + (process.platform === 'win32' ? ' (run_command uses cmd.exe: chain with &&, no bash-only syntax)' : '') + '\nTop level:\n' + names.join('\n');
  }

  async execute(call, signal) {
    const a = call.attrs;
    switch (call.name) {
      case 'list_dir':
        return this.listDir(a.path || '.');
      case 'read_file':
        return this.readFile(a.path, a.start, a.end);
      case 'search':
        return this.search(a.pattern, a.glob, signal);
      case 'write_file':
        return this.writeFile(a.path, call.body);
      case 'edit_file':
        return this.editFile(a.path, call.body);
      case 'run_command':
        return this.runCommand(call.body, signal);
      default:
        throw new Error('unknown tool: ' + call.name);
    }
  }

  async listDir(rel) {
    const root = this.root();
    const abs = path.resolve(root, rel.trim() || '.');
    const relative = path.relative(root, abs);
    if (isOutside(relative)) throw new Error('path is outside the workspace: ' + rel);
    if (GIT_DIR.test(relative)) throw new Error('access blocked: ' + relative);
    if (relative) await this.resolve(relative); // symlink check for sub-folders
    const entries = await fs.readdir(abs, { withFileTypes: true });
    const shown = entries.filter((e) => !SKIP_DIRS.has(e.name) && !SENSITIVE.test(e.name)).sort(byDirThenName);
    const lines = shown.slice(0, 200).map((e) => e.name + (e.isDirectory() ? '/' : ''));
    if (shown.length > 200) lines.push('[' + (shown.length - 200) + ' more entries not shown]');
    return lines.length ? lines.join('\n') : '(empty)';
  }

  async readFile(rel, startAttr, endAttr) {
    const { abs, relative } = await this.resolve(rel);
    const st = await fs.stat(abs);
    if (!st.isFile()) throw new Error('not a file: ' + relative);
    if (st.size > MAX_FILE_BYTES) throw new Error('file larger than 1 MB: ' + relative);
    const text = await fs.readFile(abs, 'utf8');
    if (text.includes('\u0000')) throw new Error('binary file: ' + relative);

    const lines = text.split(/\r?\n/);
    const total = lines.length;
    const start = Math.max(1, parseInt(startAttr, 10) || 1);
    const end = Math.min(total, parseInt(endAttr, 10) || total);
    if (start > total) throw new Error('start is beyond the end of the file (' + total + ' lines)');

    const out = [];
    let size = 0;
    let last = start - 1;
    for (let i = start; i <= end; i++) {
      const line = lines[i - 1].slice(0, RESULT_CAP);
      if (out.length && size + line.length + 1 > RESULT_CAP) break;
      out.push(line);
      size += line.length + 1;
      last = i;
    }
    let header = 'file: ' + relative.replace(/\\/g, '/') + ' (lines ' + start + '-' + last + ' of ' + total + ')';
    if (last < end) header += ' [truncated: continue with start=' + (last + 1) + ']';
    return header + '\n' + out.join('\n');
  }

  async search(pattern, glob, signal) {
    if (typeof pattern !== 'string' || !pattern) throw new Error('missing pattern attribute');
    let re;
    try {
      re = new RegExp(pattern, 'i');
    } catch (e) {
      re = new RegExp(escapeRegExp(pattern), 'i');
    }
    const include = typeof glob === 'string' && glob.trim() ? glob.trim() : '**/*';
    // Typical dependency and build-output folders are skipped.
    const exclude = '{**/node_modules/**,**/.git/**,**/build/**,**/.gradle/**,**/dist/**,**/out/**}';
    const files = await vscode.workspace.findFiles(include, exclude, 2000);
    const root = this.root();
    const hits = [];

    for (const uri of files) {
      if (signal.aborted) throw new Error('cancelled');
      const rel = path.relative(root, uri.fsPath);
      if (SENSITIVE.test(rel) || GIT_DIR.test(rel)) continue;
      let text;
      try {
        const st = await fs.stat(uri.fsPath);
        if (st.size > 512 * 1024) continue;
        text = await fs.readFile(uri.fsPath, 'utf8');
      } catch (e) {
        continue;
      }
      if (text.includes('\u0000')) continue;
      const lines = text.split(/\r?\n/);
      for (let i = 0; i < lines.length && hits.length < 40; i++) {
        if (re.test(lines[i])) hits.push(rel.replace(/\\/g, '/') + ':' + (i + 1) + ': ' + lines[i].trim().slice(0, 160));
      }
      if (hits.length >= 40) break;
    }
    if (!hits.length) return 'no match';
    return hits.join('\n') + (hits.length >= 40 ? '\n[first 40 matches only]' : '');
  }

  async writeFile(rel, body) {
    const { abs, relative } = await this.resolve(rel);
    const content = unfence(body).replace(/\s+$/, '') + '\n';
    if (content.length > MAX_WRITE_CHARS) throw new Error('content too large');

    let existed = true;
    try {
      const st = await fs.stat(abs);
      if (!st.isFile()) throw new Error('not a file: ' + relative);
    } catch (e) {
      if (e && e.code === 'ENOENT') existed = false;
      else throw e;
    }

    const lineCount = content.split('\n').length - 1;
    const ok = await this.confirm(
      'write',
      (existed ? 'Remplacer le fichier ' : 'Créer le fichier ') + relative + ' ?',
      lineCount + ' lignes, ' + content.length + ' caractères\n\n' + preview(content, 14)
    );
    if (!ok) return 'REFUSED by the user. Do not retry the same write; ask what they prefer.';

    await fs.mkdir(path.dirname(abs), { recursive: true });
    await fs.writeFile(abs, content, 'utf8');
    return 'OK: ' + (existed ? 'replaced ' : 'created ') + relative.replace(/\\/g, '/') + ' (' + lineCount + ' lines)';
  }

  async editFile(rel, body) {
    const { abs, relative } = await this.resolve(rel);
    const pairs = parseEditPairs(body);
    const st = await fs.stat(abs);
    if (!st.isFile()) throw new Error('not a file: ' + relative);
    if (st.size > MAX_FILE_BYTES) throw new Error('file larger than 1 MB: ' + relative);
    const original = await fs.readFile(abs, 'utf8');
    const updated = applyEdits(original, pairs); // throws before anything is written

    const detail = pairs
      .slice(0, 3)
      .map((p) => '- ' + preview(p.search.trim(), 5).split('\n').join('\n- ') + '\n+ ' + preview(p.replace.trim(), 5).split('\n').join('\n+ '))
      .join('\n\n');
    const ok = await this.confirm(
      'write',
      'Modifier le fichier ' + relative + ' (' + pairs.length + ' changement' + (pairs.length > 1 ? 's' : '') + ') ?',
      detail
    );
    if (!ok) return 'REFUSED by the user. Do not retry the same edit; ask what they prefer.';

    await fs.writeFile(abs, updated, 'utf8');
    return 'OK: edited ' + relative.replace(/\\/g, '/') + ' (' + pairs.length + ' change' + (pairs.length > 1 ? 's' : '') + ')';
  }

  async runCommand(body, signal) {
    const command = unfence(body).trim();
    if (!command) throw new Error('empty command');
    if (command.length > 1000) throw new Error('command too long');
    const cwd = this.root();

    const ok = await this.confirm('run', 'Exécuter cette commande ?', command + '\n\nDossier : ' + cwd);
    if (!ok) return 'REFUSED by the user. Do not retry; ask what they prefer.';

    return new Promise((resolve) => {
      exec(command, { cwd, timeout: 60000, maxBuffer: 1024 * 1024, windowsHide: true, signal }, (err, stdout, stderr) => {
        const code = err ? (typeof err.code === 'number' ? err.code : 'error') : 0;
        const out = ((stdout || '') + (stderr ? '\n[stderr]\n' + stderr : '')).trim();
        const flag = err && err.killed ? ' (timeout after 60 s or cancelled)' : '';
        resolve('exit ' + code + flag + '\n' + headTail(out || '(no output)', RESULT_CAP));
      });
    });
  }
}

module.exports = { Tools };