'use strict';

// Thin client for the Unlimited Claud site (Pages Functions). Uses the global fetch of Node 18+.

class ApiError extends Error {
  constructor(code, status, extra) {
    super(code || 'HTTP ' + status);
    this.code = code || '';
    this.status = status || 0;
    this.extra = extra || {};
  }
}

async function request(url, { method, headers, body, signal, timeoutMs }) {
  const verb = method || 'POST';
  const ctrl = new AbortController();
  let timedOut = false;
  const timer = setTimeout(() => {
    timedOut = true;
    ctrl.abort();
  }, timeoutMs || 100000);
  const onAbort = () => ctrl.abort();
  if (signal) {
    if (signal.aborted) ctrl.abort();
    else signal.addEventListener('abort', onAbort, { once: true });
  }

  try {
    const init = {
      method: verb,
      headers: Object.assign(verb === 'POST' ? { 'content-type': 'application/json' } : {}, headers || {}),
      signal: ctrl.signal
    };
    if (verb === 'POST') init.body = JSON.stringify(body);
    const res = await fetch(url, init);
    let data = {};
    try {
      data = await res.json();
    } catch (e) {
      data = {};
    }
    if (!res.ok) throw new ApiError(data && data.error, res.status, data);
    return data;
  } catch (e) {
    if (e instanceof ApiError) throw e;
    if (signal && signal.aborted) throw new ApiError('cancelled', 0);
    if (timedOut) throw new ApiError('timeout', 0);
    throw new ApiError('network', 0, { message: String((e && e.message) || e) });
  } finally {
    clearTimeout(timer);
    if (signal) signal.removeEventListener('abort', onAbort);
  }
}

function login(baseUrl, username, password, signal) {
  return request(baseUrl + '/api/account', {
    body: { action: 'login', username, password },
    signal,
    timeoutMs: 30000
  });
}

// Best effort: the local token is deleted by the caller whatever happens here.
function logout(baseUrl, session) {
  return request(baseUrl + '/api/account', {
    headers: { 'x-uc-session': session },
    body: { action: 'logout' },
    timeoutMs: 10000
  }).catch(() => undefined);
}

// Browser pairing: asks the site for a device code + a short user code to compare in the browser.
function deviceStart(baseUrl, signal) {
  return request(baseUrl + '/api/device', { body: { action: 'start' }, signal, timeoutMs: 20000 });
}

// Returns { status: 'pending' } or { status: 'approved', token, user, key }. Throws 'expired' (410) when too late.
function devicePoll(baseUrl, deviceCode, signal) {
  return request(baseUrl + '/api/device', {
    body: { action: 'poll', deviceCode },
    signal,
    timeoutMs: 20000
  });
}

// Plan, quota and model list for the premium key (if any). Does not need a session.
function status(baseUrl, key, signal) {
  const headers = {};
  if (key) headers['x-uc-key'] = key;
  return request(baseUrl + '/api/status', { method: 'GET', headers, signal, timeoutMs: 20000 });
}

function chat({ baseUrl, session, key, model, effort, instructions, messages, signal }) {
  // x-uc-client lets the server refuse this client when no active premium key is sent.
  const headers = { 'x-uc-session': session, 'x-uc-client': 'vscode' };
  if (key) headers['x-uc-key'] = key;
  return request(baseUrl + '/api/chat', {
    headers,
    body: { model, effort, instructions, messages },
    signal
  });
}

const MESSAGES = {
  login_required: "Session absente ou expirée. Utilise « Unlimited Claud : Se connecter ».",
  premium_required: "L'extension demande une clé premium active. Utilise « Unlimited Claud : Entrer une clé premium ».",
  slow_down: 'Trop de requêtes en peu de temps. Patiente un instant puis réessaie.',
  capacity: "Le service IA est saturé. Réessaie plus tard.",
  ai_unavailable: "Le service IA est indisponible pour le moment.",
  not_configured: "Le site n'est pas entièrement configuré (service IA ou stockage).",
  empty: "Le modèle a renvoyé une réponse vide. Réessaie.",
  unknown_model: "Modèle inconnu : choisis-en un autre avec le sélecteur de modèle.",
  bad_request: 'Requête refusée par le site (format invalide).',
  too_large: 'Requête trop volumineuse.',
  bad_credentials: "Nom d'utilisateur ou mot de passe incorrect. Un compte créé uniquement avec Google n'a pas de mot de passe.",
  locked: 'Compte verrouillé quelques minutes après trop d’échecs.',
  timeout: 'Le site met trop de temps à répondre.',
  network: 'Impossible de joindre le site.',
  expired: 'La demande de connexion a expiré. Relance « Se connecter avec le site ».'
};

function describeError(err) {
  if (!err) return 'Erreur inconnue.';
  if (err.code === 'quota') {
    return 'Quota quotidien atteint. Chaque étape de l’agent compte comme un message.';
  }
  if (err.code === 'ai_unavailable' && err.extra && err.extra.upstream) {
    const name = err.extra.model || 'ce modèle';
    return 'Erreur ' + err.status + ' : ' + name + " ne répond pas chez le fournisseur (HTTP " + err.extra.upstream +
      '). Réessaie, ou choisis un autre modèle (les Gemini répondent) avec le sélecteur de modèle.';
  }
  if (MESSAGES[err.code]) {
    const detail = err.code === 'network' && err.extra && err.extra.message ? ' (' + err.extra.message + ')' : '';
    return MESSAGES[err.code] + detail;
  }
  return (err.extra && err.extra.message) || err.message || 'Erreur inconnue.';
}

module.exports = { ApiError, login, logout, deviceStart, devicePoll, status, chat, describeError };