'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { clean, compose, LIBRARY, MAX_SKILLS, NAME_MAX, TEXT_MAX, TOTAL_MAX } = require('./skills');

test('clean drops invalid entries and trims fields', () => {
  const out = clean([
    { id: 'a', name: '  Revue  ', text: '  cherche les bugs  ', on: true },
    { name: '', text: 'sans nom' },
    { name: 'sans texte', text: '   ' },
    null,
    'texte'
  ]);
  assert.equal(out.length, 1);
  assert.equal(out[0].name, 'Revue');
  assert.equal(out[0].text, 'cherche les bugs');
});

test('clean returns an empty list for non-arrays', () => {
  assert.deepEqual(clean(undefined), []);
  assert.deepEqual(clean({}), []);
});

test('clean caps count, name and text lengths and generates missing ids', () => {
  const many = Array.from({ length: MAX_SKILLS + 5 }, (_, i) => ({ name: 'n' + i, text: 't' }));
  assert.equal(clean(many).length, MAX_SKILLS);

  const [s] = clean([{ name: 'x'.repeat(NAME_MAX + 10), text: 'y'.repeat(TEXT_MAX + 10) }]);
  assert.equal(s.name.length, NAME_MAX);
  assert.equal(s.text.length, TEXT_MAX);
  assert.ok(s.id.length > 0);
});

test('compose keeps only enabled skills', () => {
  const text = compose([
    { name: 'A', text: 'un', on: true },
    { name: 'B', text: 'deux', on: false }
  ]);
  assert.equal(text, 'Skill "A":\nun');
});

test('compose returns an empty string when nothing is enabled', () => {
  assert.equal(compose([]), '');
  assert.equal(compose([{ name: 'A', text: 'un', on: false }]), '');
});

test('compose never exceeds the total cap', () => {
  const list = Array.from({ length: MAX_SKILLS }, (_, i) => ({ name: 's' + i, text: 'z'.repeat(TEXT_MAX), on: true }));
  assert.ok(compose(list).length <= TOTAL_MAX);
});

test('library skills respect the limits and have unique names', () => {
  assert.ok(LIBRARY.length >= 10);
  assert.ok(LIBRARY.length <= MAX_SKILLS);
  assert.equal(new Set(LIBRARY.map((s) => s.name)).size, LIBRARY.length);
  for (const s of LIBRARY) {
    assert.ok(s.name.length > 0 && s.name.length <= NAME_MAX, s.name);
    assert.ok(s.text.length > 0 && s.text.length <= TEXT_MAX, s.name);
  }
  assert.equal(clean(LIBRARY).length, LIBRARY.length);
});