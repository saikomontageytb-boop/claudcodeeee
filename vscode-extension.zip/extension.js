'use strict';

const vscode = require('vscode');
const {
  login: apiLogin,
  logout: apiLogout,
  deviceStart,
  devicePoll,
  status: apiStatus,
  ApiError,
  describeError
} = require('./api');
const { Agent } = require('./agent');
const { Tools } = require('./tools');
const { ChatView } = require('./view');
const { clean, compose, makeId, LIBRARY, MAX_SKILLS, NAME_MAX, TEXT_MAX } = require('./skills');

const SESSION_SECRET = 'unlimitedClaud.session';
const KEY_SECRET = 'unlimitedClaud.key';
const SKILLS_KEY = 'unlimitedClaud.skills';
const DEFAULT_MODEL = 'unli-auto';

const PROBLEMS = {
  invalid: 'Le format de cette clé est invalide (attendu : UC-XXXX-XXXX-XXXX-XXXX).',
  inactive: "Cette clé n'est pas encore activée : active-la d'abord sur le site.",
  expired: 'Cette clé a expiré.',
  revoked: 'Cette clé a été révoquée.'
};

function settings() {
  return vscode.workspace.getConfiguration('unlimitedClaud');
}

// The session token is sent in a header: only https (or localhost for tests) is accepted.
function baseUrl() {
  const raw = String(settings().get('baseUrl') || '').trim();
  let url;
  try {
    url = new URL(raw);
  } catch (e) {
    throw new Error('Réglage unlimitedClaud.baseUrl invalide.');
  }
  const local = url.hostname === 'localhost' || url.hostname === '127.0.0.1';
  if (url.protocol !== 'https:' && !(local && url.protocol === 'http:')) {
    throw new Error('unlimitedClaud.baseUrl doit commencer par https://.');
  }
  return url.origin;
}

// Keeps the reasoning effort valid for the chosen model (the list of levels comes from the site).
function fitEffort(cfg, models) {
  const m = (models || []).find((x) => x.id === cfg.model);
  const list = m && Array.isArray(m.efforts) && m.efforts.length ? m.efforts : null;
  if (!list || list.includes(cfg.effort)) return cfg;
  const effort = list.includes('med') ? 'med' : list.includes('high') ? 'high' : list[Math.floor(list.length / 2)];
  return Object.assign({}, cfg, { effort });
}

function currentSettings() {
  const s = settings();
  const steps = Number(s.get('maxSteps'));
  const effort = s.get('effort');
  return {
    model: String(s.get('model') || DEFAULT_MODEL).trim(),
    effort: ['none', 'minimal', 'low', 'med', 'high', 'xhigh', 'max'].includes(effort) ? effort : 'med',
    permissions: ['readOnly', 'ask', 'all'].includes(s.get('permissions')) ? s.get('permissions') : 'ask',
    maxSteps: Number.isInteger(steps) && steps >= 1 && steps <= 40 ? steps : 12
  };
}

function toApiError(e) {
  return e instanceof ApiError ? e : new ApiError('error', 0, { message: String((e && e.message) || e) });
}

function activate(context) {
  const secrets = context.secrets;
  const tools = new Tools(() => currentSettings().permissions);
  let running = false;
  let controller = null;
  // Result of the last /api/status call. The extension only works with an active premium key.
  let access = { checked: false, premium: false, models: [] };

  const agent = new Agent({
    tools,
    getBaseUrl: baseUrl,
    getSettings: () => fitEffort(currentSettings(), access.models),
    getAuth: async () => ({
      session: await secrets.get(SESSION_SECRET),
      key: await secrets.get(KEY_SECRET)
    }),
    getSkills: () => compose(loadSkills())
  });

  const view = new ChatView(
    {
      onSend: (text, agentMode) => send(text, agentMode),
      onStop: () => {
        if (controller) controller.abort();
      },
      onClear: () => newChat(),
      onLogin: () => {
        void login();
      },
      onSetKey: () => {
        void setKey();
      },
      onModel: (id) => {
        void pickModel(id);
      },
      onOpenSite: () => {
        try {
          void vscode.env.openExternal(vscode.Uri.parse(baseUrl()));
        } catch (e) {
          void vscode.window.showErrorMessage(String((e && e.message) || e));
        }
      },
      onRetry: () => {
        void refreshAccess();
      },
      onReady: () => {
        syncSkills();
        void refreshAccess();
      },
      onSkills: () => {
        void manageSkills();
      },
      onLogout: () => {
        void logout();
      },
      onPickModel: () => {
        void selectModelCommand();
      },
      onSkillToggle: (id) => {
        void toggleSkill(id);
      },
      onEffort: (value) => {
        void pickEffort(value);
      },
      onPermissions: (value) => {
        void pickPermissions(value);
      },
      onAttach: () => {
        void attachFiles();
      },
      onDetach: (index) => {
        detachFile(index);
      }
    },
    context.extensionUri
  );

  const ui = {
    status: (text) => view.setStatus(text),
    assistant: (text) => view.add('assistant', text),
    tool: (text) => view.add('tool', text),
    error: (text) => view.add('error', text)
  };

  function syncModels() {
    const cfg = fitEffort(currentSettings(), access.models);
    view.setModels(access.models, cfg.model);
    view.setPrefs({ effort: cfg.effort, permissions: cfg.permissions });
  }

  const EFFORT_IDS = ['none', 'minimal', 'low', 'med', 'high', 'xhigh', 'max'];
  const PERMISSION_IDS = ['readOnly', 'ask', 'all'];

  async function saveSetting(key, value) {
    try {
      await settings().update(key, value, vscode.ConfigurationTarget.Global);
    } catch (e) {
      void vscode.window.showErrorMessage('Impossible d’enregistrer le réglage : ' + String((e && e.message) || e));
    }
    syncModels();
  }

  async function pickEffort(value) {
    const m = access.models.find((x) => x.id === currentSettings().model);
    const allowed = m && Array.isArray(m.efforts) && m.efforts.length ? m.efforts : EFFORT_IDS;
    if (!allowed.includes(value)) return;
    await saveSetting('effort', value);
  }

  async function pickPermissions(value) {
    if (!PERMISSION_IDS.includes(value)) return;
    if (value === 'all') {
      const ok = await vscode.window.showWarningMessage(
        "Autoriser l'agent à modifier les fichiers et lancer des commandes sans demander ton accord ?",
        { modal: true },
        'Tout autoriser'
      );
      if (ok !== 'Tout autoriser') return;
    }
    await saveSetting('permissions', value);
  }

  // Files imported by the user, sent with the next message: [{ name, text }].
  const MAX_ATTACHED = 5;
  const MAX_ATTACH_BYTES = 1024 * 1024;
  const ATTACH_CHARS = 30000;
  let attached = [];

  function syncAttached() {
    view.setAttachments(attached.map((f) => ({ name: f.name, size: f.text.length })));
  }

  async function attachFiles() {
    const picked = await vscode.window.showOpenDialog({
      canSelectMany: true,
      canSelectFolders: false,
      openLabel: 'Joindre',
      title: 'Joindre des fichiers à la conversation'
    });
    if (!picked || !picked.length) return;
    for (const uri of picked) {
      const name = uri.path.split('/').pop() || 'fichier';
      if (attached.length >= MAX_ATTACHED) {
        void vscode.window.showWarningMessage('Maximum ' + MAX_ATTACHED + ' fichiers par message.');
        break;
      }
      try {
        const bytes = await vscode.workspace.fs.readFile(uri);
        if (bytes.byteLength > MAX_ATTACH_BYTES) {
          void vscode.window.showWarningMessage(name + ' : fichier trop volumineux (1 Mo maximum).');
          continue;
        }
        if (bytes.subarray(0, 8000).includes(0)) {
          void vscode.window.showWarningMessage(name + ' : seuls les fichiers texte peuvent être joints.');
          continue;
        }
        let text = Buffer.from(bytes).toString('utf8');
        if (text.length > ATTACH_CHARS) text = text.slice(0, ATTACH_CHARS) + '\n[cut]';
        attached.push({ name, text });
      } catch (e) {
        void vscode.window.showWarningMessage(name + ' : lecture impossible.');
      }
    }
    syncAttached();
  }

  function detachFile(index) {
    if (!Number.isInteger(index) || index < 0 || index >= attached.length) return;
    attached.splice(index, 1);
    syncAttached();
  }

  // Keeps the saved model valid: if it is not in the site's list, fall back to a sensible one.
  async function ensureModel() {
    if (!access.models.length) return;
    const wanted = currentSettings().model;
    if (access.models.some((m) => m.id === wanted)) return;
    const fallback = access.models.find((m) => m.id === DEFAULT_MODEL) || access.models[0];
    try {
      await settings().update('model', fallback.id, vscode.ConfigurationTarget.Global);
    } catch (e) {
      // the picker still shows the first model; the next change will persist it
    }
  }

  async function pickModel(id) {
    if (!access.models.some((m) => m.id === id)) return;
    try {
      await settings().update('model', id, vscode.ConfigurationTarget.Global);
    } catch (e) {
      void vscode.window.showErrorMessage('Impossible d’enregistrer le modèle : ' + String((e && e.message) || e));
    }
    syncModels();
  }

  async function selectModelCommand() {
    if (!access.premium) {
      void vscode.window.showInformationMessage('Le choix du modèle est réservé aux clés premium actives.');
      return;
    }
    const current = currentSettings().model;
    const picked = await vscode.window.showQuickPick(
      access.models.map((m) => ({
        label: m.label,
        description: m.id === current ? 'actuel' : m.reasoning ? 'raisonnement' : '',
        id: m.id
      })),
      { placeHolder: 'Choisir le modèle', matchOnDescription: true }
    );
    if (picked) await pickModel(picked.id);
  }

  async function refreshAccess() {
    view.setAccess({ state: 'checking' });
    const key = await secrets.get(KEY_SECRET);
    let st;
    try {
      st = await apiStatus(baseUrl(), key);
    } catch (e) {
      access = { checked: false, premium: false, models: [] };
      view.setAccess({ state: 'error', text: describeError(toApiError(e)) });
      return false;
    }

    const premium = Boolean(st && st.tier === 'paid');
    const models = (Array.isArray(st && st.models) ? st.models : [])
      .filter((m) => m && typeof m.id === 'string' && typeof m.label === 'string')
      .map((m) => ({
        id: m.id,
        label: m.label,
        reasoning: Boolean(m.reasoning),
        efforts: Array.isArray(m.efforts) ? m.efforts.filter((x) => typeof x === 'string') : ['low', 'med', 'high']
      }));
    access = { checked: true, premium, models: premium ? models : [] };

    if (premium) {
      await ensureModel();
      syncModels();
      view.setAccess({
        state: 'premium',
        plan: typeof st.plan === 'string' ? st.plan : '',
        expires: st.expiresAt ? 'Expire le ' + new Date(st.expiresAt).toLocaleDateString('fr-FR') : ''
      });
    } else {
      const text = key
        ? PROBLEMS[st && st.problem] || 'Cette clé ne donne pas accès au Premium.'
        : "L'extension est réservée aux membres Premium. Entre ta clé (UC-…), déjà activée sur le site, pour la débloquer.";
      view.setModels([], '');
      view.setAccess({ state: 'locked', text });
    }
    return premium;
  }

  function newChat() {
    if (running && controller) controller.abort();
    agent.clear();
    view.reset();
    view.setStatus('');
  }

  async function loginPassword() {
    const username = await vscode.window.showInputBox({
      prompt: "Nom d'utilisateur Unlimited Claud",
      ignoreFocusOut: true
    });
    if (!username || !username.trim()) return false;
    const password = await vscode.window.showInputBox({
      prompt: 'Mot de passe',
      password: true,
      ignoreFocusOut: true
    });
    if (!password) return false;

    try {
      const res = await apiLogin(baseUrl(), username.trim(), password);
      if (!res || typeof res.token !== 'string' || !res.token) throw new ApiError('bad_request', 0);
      await secrets.store(SESSION_SECRET, res.token);
      view.add('info', 'Connecté en tant que ' + (res.user || username.trim()) + '.');
      return true;
    } catch (e) {
      void vscode.window.showErrorMessage(describeError(toApiError(e)));
      return false;
    }
  }

  // Browser pairing: opens the site (already signed in there), the user confirms, the extension picks up a session.
  async function loginWithSite() {
    let base;
    try {
      base = baseUrl();
    } catch (e) {
      void vscode.window.showErrorMessage(String((e && e.message) || e));
      return false;
    }
    const ctl = new AbortController();
    const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

    return vscode.window.withProgress(
      { location: vscode.ProgressLocation.Notification, title: 'Unlimited Claud', cancellable: true },
      async (progress, token) => {
        token.onCancellationRequested(() => ctl.abort());
        try {
          progress.report({ message: 'Ouverture du navigateur…' });
          const start = await deviceStart(base, ctl.signal);
          if (!start || typeof start.deviceCode !== 'string' || typeof start.userCode !== 'string') {
            throw new ApiError('bad_request', 0);
          }
          const url = base + '/connect.html?code=' + encodeURIComponent(start.userCode);
          await vscode.env.openExternal(vscode.Uri.parse(url));
          progress.report({ message: 'Confirme dans le navigateur (code ' + start.userCode + ')…' });

          const ttl = Math.min(Number(start.expiresIn) || 600, 600);
          const interval = Math.max(Number(start.interval) || 2, 2);
          const deadline = Date.now() + ttl * 1000;

          while (Date.now() < deadline) {
            await sleep(interval * 1000);
            if (ctl.signal.aborted) throw new ApiError('cancelled', 0);
            let res;
            try {
              res = await devicePoll(base, start.deviceCode, ctl.signal);
            } catch (e) {
              const err = toApiError(e);
              if (err.code === 'network' || err.code === 'timeout' || err.code === 'slow_down') continue;
              throw err;
            }
            if (res && res.status === 'approved' && typeof res.token === 'string' && res.token) {
              await secrets.store(SESSION_SECRET, res.token);
              if (typeof res.key === 'string' && res.key) await secrets.store(KEY_SECRET, res.key);
              view.add('info', 'Connecté en tant que ' + (res.user || 'ton compte') + '.');
              await refreshAccess();
              return true;
            }
          }
          throw new ApiError('expired', 410);
        } catch (e) {
          const err = toApiError(e);
          if (err.code !== 'cancelled') void vscode.window.showErrorMessage(describeError(err));
          return false;
        }
      }
    );
  }

  async function login() {
    const pick = await vscode.window.showQuickPick(
      [
        {
          label: '$(globe) Se connecter avec le site',
          description: 'Recommandé : tu es déjà connecté dans ton navigateur',
          id: 'site'
        },
        { label: '$(key) Nom d’utilisateur et mot de passe', id: 'password' }
      ],
      { placeHolder: 'Comment veux-tu te connecter ?', ignoreFocusOut: true }
    );
    if (!pick) return false;
    return pick.id === 'site' ? loginWithSite() : loginPassword();
  }

  async function logout() {
    const session = await secrets.get(SESSION_SECRET);
    await secrets.delete(SESSION_SECRET);
    if (session) {
      try {
        await apiLogout(baseUrl(), session);
      } catch (e) {
        // best effort: the local token is already gone
      }
    }
    view.add('info', 'Déconnecté.');
  }

  async function setKey() {
    const value = await vscode.window.showInputBox({
      prompt: 'Clé premium (UC-…), déjà activée sur le site. Laisse vide pour la retirer.',
      password: true,
      ignoreFocusOut: true
    });
    if (value === undefined) return;
    if (!value.trim()) {
      await secrets.delete(KEY_SECRET);
      view.add('info', 'Clé retirée.');
    } else {
      await secrets.store(KEY_SECRET, value.trim());
    }
    await refreshAccess();
  }

  function loadSkills() {
    return clean(context.globalState.get(SKILLS_KEY, []));
  }

  async function saveSkills(list) {
    await context.globalState.update(SKILLS_KEY, clean(list));
    syncSkills();
  }

  // Sends the skills list to the chat so that /skills can suggest and toggle them.
  function syncSkills() {
    view.setSkills(loadSkills().map((s) => ({ id: s.id, name: s.name, on: s.on })));
  }

  async function toggleSkill(id) {
    const list = loadSkills();
    const skill = list.find((s) => s.id === id);
    if (!skill) return;
    skill.on = !skill.on;
    await saveSkills(list);
  }

  async function addSkill() {
    const list = loadSkills();
    if (list.length >= MAX_SKILLS) {
      void vscode.window.showWarningMessage('Maximum ' + MAX_SKILLS + ' skills.');
      return;
    }
    const name = await vscode.window.showInputBox({
      prompt: 'Nom du skill',
      ignoreFocusOut: true,
      validateInput: (v) => (v.trim() ? (v.length > NAME_MAX ? NAME_MAX + ' caractères maximum.' : null) : 'Le nom est obligatoire.')
    });
    if (!name || !name.trim()) return;
    const text = await vscode.window.showInputBox({
      prompt: 'Instructions du skill (ex. : quand je demande du code, ajoute toujours des tests)',
      ignoreFocusOut: true,
      validateInput: (v) => (v.trim() ? (v.length > TEXT_MAX ? TEXT_MAX + ' caractères maximum.' : null) : 'Les instructions sont obligatoires.')
    });
    if (!text || !text.trim()) return;
    list.push({ id: makeId(), name: name.trim(), text: text.trim(), on: true });
    await saveSkills(list);
    view.add('info', 'Skill « ' + name.trim() + ' » ajouté.');
  }

  // Multi-select quick pick over the preset library; the chosen skills are added enabled.
  async function addFromLibrary() {
    const list = loadSkills();
    const have = new Set(list.map((s) => s.name));
    const items = LIBRARY.filter((s) => !have.has(s.name)).map((s) => ({
      label: s.name,
      description: s.desc,
      detail: s.text.length > 100 ? s.text.slice(0, 100) + '…' : s.text,
      skill: s
    }));
    if (!items.length) {
      void vscode.window.showInformationMessage('Tous les skills de la bibliothèque sont déjà ajoutés.');
      return;
    }
    const picks = await vscode.window.showQuickPick(items, {
      canPickMany: true,
      placeHolder: 'Bibliothèque : coche les skills à ajouter (' + list.length + '/' + MAX_SKILLS + ')',
      ignoreFocusOut: true,
      matchOnDetail: true
    });
    if (!picks || !picks.length) return;
    const room = Math.max(MAX_SKILLS - list.length, 0);
    const chosen = picks.slice(0, room);
    for (const p of chosen) {
      list.push({ id: makeId(), name: p.skill.name, text: p.skill.text, on: true });
    }
    if (chosen.length) await saveSkills(list);
    if (picks.length > room) {
      void vscode.window.showWarningMessage('Maximum ' + MAX_SKILLS + ' skills : ' + (picks.length - room) + ' non ajouté(s).');
    }
    if (chosen.length) view.add('info', chosen.length + ' skill(s) ajouté(s) depuis la bibliothèque.');
  }

  // Quick pick loop: add a skill, or pick one to enable/disable/delete it.
  async function manageSkills() {
    for (;;) {
      const list = loadSkills();
      const items = [{ label: '$(add) Ajouter un skill', id: '__add' }, { label: '$(library) Bibliothèque de skills', id: '__lib' }].concat(
        list.map((s) => ({
          label: (s.on ? '$(check) ' : '$(circle-slash) ') + s.name,
          description: s.on ? 'activé' : 'désactivé',
          detail: s.text.length > 100 ? s.text.slice(0, 100) + '…' : s.text,
          id: s.id
        }))
      );
      const pick = await vscode.window.showQuickPick(items, {
        placeHolder: list.length ? 'Skills (' + list.length + '/' + MAX_SKILLS + ')' : 'Aucun skill pour le moment',
        ignoreFocusOut: true,
        matchOnDetail: true
      });
      if (!pick) return;
      if (pick.id === '__lib') {
        await addFromLibrary();
        continue;
      }
      if (pick.id === '__add') {
        await addSkill();
        continue;
      }
      const skill = list.find((s) => s.id === pick.id);
      if (!skill) continue;
      const action = await vscode.window.showQuickPick(
        [
          { label: skill.on ? '$(circle-slash) Désactiver' : '$(check) Activer', id: 'toggle' },
          { label: '$(trash) Supprimer', id: 'delete' }
        ],
        { placeHolder: skill.name, ignoreFocusOut: true }
      );
      if (!action) continue;
      if (action.id === 'toggle') skill.on = !skill.on;
      await saveSkills(action.id === 'delete' ? list.filter((s) => s.id !== skill.id) : list);
    }
  }

  async function send(text, agentMode) {
    if (running) return;
    running = true;
    controller = new AbortController();
    view.setBusy(true);

    try {
      if (!access.checked) await refreshAccess();
      if (!access.premium) {
        view.add('error', "L'extension est réservée aux clés premium actives. Entre ta clé pour continuer.");
        return;
      }
      const files = attached.slice();
      view.add('user', files.length ? text + '\n\n[Fichiers : ' + files.map((f) => f.name).join(', ') + ']' : text);
      if (!(await secrets.get(SESSION_SECRET)) && !(await login())) {
        view.add('error', "Connexion requise pour utiliser l'agent.");
        return;
      }
      attached = [];
      syncAttached();
      await agent.run(text, { agentMode, signal: controller.signal, ui, files });
    } catch (e) {
      const err = toApiError(e);
      if (err.code === 'cancelled') {
        view.add('info', 'Arrêté.');
      } else {
        view.add('error', describeError(err));
        if (err.code === 'login_required') await secrets.delete(SESSION_SECRET);
        if (err.code === 'premium_required') void refreshAccess();
      }
    } finally {
      running = false;
      controller = null;
      view.setBusy(false);
      view.setStatus('');
    }
  }

  context.subscriptions.push(
    vscode.window.registerWebviewViewProvider('unlimitedClaud.chat', view, {
      webviewOptions: { retainContextWhenHidden: true }
    }),
    vscode.commands.registerCommand('unlimitedClaud.focus', () =>
      vscode.commands.executeCommand('unlimitedClaud.chat.focus')
    ),
    vscode.commands.registerCommand('unlimitedClaud.newChat', newChat),
    vscode.commands.registerCommand('unlimitedClaud.selectModel', selectModelCommand),
    vscode.commands.registerCommand('unlimitedClaud.login', login),
    vscode.commands.registerCommand('unlimitedClaud.logout', logout),
    vscode.commands.registerCommand('unlimitedClaud.setKey', setKey),
    vscode.commands.registerCommand('unlimitedClaud.skills', manageSkills),
    vscode.workspace.onDidChangeConfiguration((e) => {
      if (!e.affectsConfiguration('unlimitedClaud')) return;
      syncModels();
      if (e.affectsConfiguration('unlimitedClaud.baseUrl')) void refreshAccess();
    })
  );
}

function deactivate() {}

module.exports = { activate, deactivate };